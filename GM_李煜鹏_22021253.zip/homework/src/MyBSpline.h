#pragma once
#include "Tiny2DEngine.h"
#include "Triangle.h"
#include <vector>
using namespace std;
using namespace Eigen;

class MyBSpline : public Tiny2DEngine {
public:
    vector<Vector2f> controlPoints;
    // set number of control points as 5, it can change later
    int k = 4;
    int n = 4;
    float dt;
    vector<float> knots;
    // Constructor
    MyBSpline(HINSTANCE hinst, int w, int h) : Tiny2DEngine(hinst, w, h) {}


    void onInit() override;

    // count P(t) recursively
    Vector2f DeBoorCox(float t, int i, int j) ;

    // Optional: Rewrite onMain function, which will get executed in the loop
    void onMain() override;
};