#include "MyBSpline.h"

void MyBSpline::onInit() {
    controlPoints.push_back(Vector2f(100, 100));
    controlPoints.push_back(Vector2f(200, 400));
    controlPoints.push_back(Vector2f(300, 300));
    controlPoints.push_back(Vector2f(400, 100));
    controlPoints.push_back(Vector2f(500, 500));

    dt = 1.f / (n+k);
    for (int i = 0; i < n+k ; i ++ )
        knots.push_back(i*dt);
    knots.push_back(1.f);
}

// count P(t) recursively
Vector2f MyBSpline::DeBoorCox(float t, int i, int j) {
    if ( j == 0 )
        return controlPoints[i];
    float tau = (t - knots[i]) / (knots[i+k-j] - knots[i]);
    return (1 - tau) * DeBoorCox(t, i-1, j-1) + tau * DeBoorCox(t, i, j-1);
}

// Optional: Rewrite onMain function, which will get executed in the loop
void MyBSpline::onMain() {
    int drawNum = 1001;
    float step = 1 / (float)(drawNum-1);       

    for (const auto &p : controlPoints) {
        drawPoint(p[0], p[1], 2, Vector3f(0,0,0));
    }

    for (int i = 0; i < drawNum; i++)
    {
        float t = i * step;
        int l = t / dt;
        // printf("%f %d", t, l);
        if( l >= k-1 && l <= n ){
            Vector2f point = DeBoorCox(t, l, k-1);
            drawPoint(point[0], point[1], 2, Vector3f(1,0,0));
            // setPixel(point[070], point[1], Vector3f(1,0,0));
        }
            
    }
    
    // setPixel(100, 100, Vector3f(1,1,1));
}
