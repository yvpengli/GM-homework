#include "MyBSplineSurface.h"
#include <stdlib.h>
#include <ctime>
#include <cmath>

float MyBSplineSurface::setKnots(vector<float> &knots, int n, int k) {
    int realNum = n-k+3;    // [k-1, n+1]
    float dt = 1.f / (realNum-1);

    for (int i = 0; i < k-1; i++)
        knots.push_back(0.f);
    for (int i = 0; i < realNum-1; i ++ )
        knots.push_back(i*dt);
    for (int i = 0; i <= k-1; i ++ )
        knots.push_back(1.f);
    return dt;
}

void MyBSplineSurface::getRandomControlPoints(vector<vector<Vector3f>> &controlPoints, int m, int n ) {
    srand( time(0) );
    float dm = 1.f / m;     // 用m限制y坐标
    float dn = 1.f / n;     // 用n限制x坐标
    for (int i = 0; i < m+1; i++)
    {
        for( int j = 0; j < n+1; j ++ ) {
            float randx = 1 - j * dn + dn * (rand() % 1000 - 500) / 500.f;
            float randy = 1 - i * dm + dm * (rand() % 1000 - 500) / 500.f;
            float randz = (rand() % 1000 - 500) / 500.f;
            controlPoints[i].push_back(Vector3f(randx, randy, randz));
        }
    }
}

float MyBSplineSurface::countBase(int i, int p, float t, vector<float> &knots) {
    if(p == 1) {
        if( t >= knots[i] && t < knots[i+1] )
            return 1;
        return 0;
    }
    float a = 0.f, b = 0.f;
    // int n = knots.size() - k - 1;
    // if ( i >= k-1 && i+p-1 < n+1 )
    //     a = (t - knots[i]) / (knots[i+p-1] - knots[i]) * countBase(i, k, p-1, t, knots);
    // if ( i+1 >= k-1 && i+p < n+1 )
    //     b = (knots[i+p] - t) / (knots[i+p] - knots[i+1]) * countBase(i+1, k, p-1, t, knots);
    if ( (knots[i+p-1] - knots[i]) != 0 )
        a = (t - knots[i]) / (knots[i+p-1] - knots[i]) * countBase(i, p-1, t, knots);
    if ( (knots[i+p] - knots[i+1]) != 0 )
        b = (knots[i+p] - t) / (knots[i+p] - knots[i+1]) * countBase(i+1, p-1, t, knots);

    return a + b;   
}


void MyBSplineSurface::getInterpolationControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k) {
    int n = dataPoints.size() - 1;
    vector<float> knots;
    float dt = setKnots(knots, n, k);

    MatrixXf D(n+1, 3), N(n+1, n+1), P(n+1, 3);
    // vector<vector<float>> dD(n+1);
    // vector<vector<float>> dN(n+1);
    // vector<vector<float>> dP(n+1);
    for (int i = 0; i < n+1; i ++)
        for(int j = 0; j < 3; j ++) {
            D(i, j) = dataPoints[i][j];
            //dD[i].push_back(dataPoints[i][j]);
        }
            
    
    // 这里参数的选择采用均匀参数
    float step = 1.f / n;
    for (int i = 0; i < n+1; i ++) {
        float t = i * step;
        if( t == 1 )
            t -= step/2;
        for (int j = 0; j < n+1; j ++) {
            N(i, j) = countBase(j, k, t, knots);
            //dN[i].push_back(N(i,j));
        }
    }
    
    P = N.inverse() * D;

    for(int i = 0; i < n+1; i ++) {
        controlPoints.push_back( Vector3f( P(i,0), P(i,1), P(i,2) ) );
    }
        
}

void MyBSplineSurface::getFittingControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k, int h) {
    int n = dataPoints.size() - 1;
    vector<float> knots;
    float dt = setKnots(knots, h, k);   // 这里的结点向量要输入h，控制顶点个数是h+1

    MatrixXf Q(h-1, 3), N(n-1, h-1), P(h-1, 3);

    // 这里也是采用均匀采样，一共有n+1个采样点,第一个采样点是t0=0,tn=1-1/2*step
    // 这个循环中产生两个矩阵N和Q, N是按列构建，Q是按行构建。
    float step = 1.f / n;
    for(int i = 1; i <= h-1; i ++ ) {
        Vector3f sumQ = Vector3f(0,0,0);
        for(int j = 1; j <= n-1; j ++){
            float t = j * step;
            N(j-1, i-1) = countBase(i, k, t, knots);
            // i,j 作为下标的时候的范围是[1,h-1]和[1,n-1]，但是作为矩阵下标时要-1
            Vector3f tempQ = dataPoints[j] - countBase(0, k, t, knots) * dataPoints[0]
                            - countBase(h, k, t, knots) * dataPoints[n];
            sumQ = sumQ + N(j-1, i-1) * tempQ;   
        }
        Q(i-1, 0) = sumQ[0];
        Q(i-1, 1) = sumQ[1];
        Q(i-1, 2) = sumQ[2];
    }

    P = (N.transpose() * N).inverse() * Q;


    controlPoints.push_back(dataPoints[0]);
    for(int i = 1; i <= h-1; i ++) {
        controlPoints.push_back( Vector3f( P(i,0), P(i,1), P(i,2) ) );
    }
    controlPoints.push_back(dataPoints[n]);

}


void MyBSplineSurface::getBSpline(int drawNum, vector<Vector3f> &rec, vector<Vector3f> &controlPoints, int k) {
    int n = controlPoints.size()-1;
    vector<float> knots;
    float dt = setKnots(knots, n, k);

    float step = 1.f / (drawNum-1);
    for (int i = 0; i < drawNum; i++)
    {
        float t = i * step;
        if (t == 1)
            t -= step;
        int l = t / dt + k - 1;
        rec.push_back(DeBoorCox(t, l, k-1, knots, controlPoints, k));
    }
}

// count P(t) recursively
Vector3f MyBSplineSurface::DeBoorCox(float t, int i, int j, vector<float> knots, vector<Vector3f> controls, int k) {
    if ( j == 0 )
        return controls[i];
    float tau = (t - knots[i]) / (knots[i+k-j] - knots[i]);
    return (1 - tau) * DeBoorCox(t, i-1, j-1, knots, controls, k) + tau * DeBoorCox(t, i, j-1, knots, controls, k);
}


void MyBSplineSurface::getBSplineSurface(int drawNumForM, int drawNumForN, vector<vector<Vector3f>> &controlPoints, int k) {
    int m = controlPoints.size()-1;
    int n = controlPoints[0].size()-1;
    
    vector<vector<Vector3f>> drawPointsRec;
    vector<vector<Vector3f>> bSplineRec;

    bSplineRec.resize(m+1);
    for( int i = 0 ; i < m+1 ; i ++ )
        getBSpline(drawNumForN, bSplineRec[i], controlPoints[i], k);
    
    drawPointsRec.resize(drawNumForN);
    
    for( int i = 0; i < drawNumForN; i ++) {
        vector<Vector3f> secondaryControls;
        for( int j = 0; j < m+1; j ++ )
            secondaryControls.push_back(bSplineRec[j][i]);
        
        getBSpline(drawNumForM, drawPointsRec[i], secondaryControls, k);
    }

    // draw triangle

    for (int i = 0; i < drawNumForN-1; i++)
    {
        for (int j = 0; j < drawNumForM-1; j++)
        {
            Triangle3D tri1{drawPointsRec[i][j],
                        drawPointsRec[i+1][j+1],
                        drawPointsRec[i][j+1]};
            Triangle3D tri2{drawPointsRec[i][j],
                        drawPointsRec[i+1][j],
                        drawPointsRec[i+1][j+1]};
            globalTriangles.push_back(tri1);
            globalTriangles.push_back(tri2);  
        }
        
    }
}

void MyBSplineSurface::getSphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n) {
    // u的范围是0-2PI, v的范围是0-PI
    float u = 0.f, v = 0.f;
    float du = 2 * PI / (n-1), dv = PI / (n-1);
    float r = 0.5;
    dataPoints.resize(n);
    for(int i = 0; i < n ; i ++ ) {
        for( int j = 0; j < n; j ++ ) {
            v = i * dv;
            u = j * du;
            dataPoints[i].push_back(Vector3f(r*sin(v)*cos(u), r*sin(v)*sin(u), r*cos(v) ) );
        }
    }
}

void MyBSplineSurface::getShakySphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n) {
    // u的范围是0-2PI, v的范围是0-PI
    float u = 0.f, v = 0.f;
    float du = 2 * PI / (n-1), dv = PI / (n-1);
    //float r = 0.5;
    dataPoints.resize(n);
    srand(time(0));
    for(int i = 0; i < n ; i ++ ) {
        for( int j = 0; j < n; j ++ ) {
            v = i * dv;
            u = j * du;
            // float dx = 1.0 / n * ( rand() % 1000 - 500 ) / 500;
            // float dy = 1.0 / n * ( rand() % 1000 - 500 ) / 500;
            // float dz = 1.0 / n * ( rand() % 1000 - 500 ) / 500;
            float r = 0.8f + ((float)(rand()%1000) / 1000.f - 0.5f ) * 0.1f;
            dataPoints[i].push_back(Vector3f(r*sin(v)*cos(u), r*sin(v)*sin(u), r*cos(v) ) );
        }
    }
}

void MyBSplineSurface::getSphereControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k) {
    int n = dataPoints.size();
    vector<vector<Vector3f>> tmpControlPoints;
    controlPoints.resize(n);
    tmpControlPoints.resize(n);

    for(int i = 0; i < n; i ++ ) {
        getInterpolationControlPoints(dataPoints[i], tmpControlPoints[i], k);
    }

    for(int i = 0; i < n; i ++ ) {
        vector<Vector3f> tmpDataPoints;
        for(int j = 0; j < n; j ++ )
            tmpDataPoints.push_back(tmpControlPoints[j][i]);
        getInterpolationControlPoints(tmpDataPoints, controlPoints[i], k);
    }

}

void MyBSplineSurface::getFittingControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k, int h) {
    int n = dataPoints.size();
    vector<vector<Vector3f>> tmpControlPoints;
    // 控制顶点数是h+1
    controlPoints.resize(h+1);
    tmpControlPoints.resize(n);

    for(int i = 0; i < n; i ++ ) {
        getFittingControlPoints(dataPoints[i], tmpControlPoints[i], k, h);
    }

    for(int i = 0; i < h+1; i ++ ) {
        vector<Vector3f> tmpDataPoints;
        for(int j = 0; j < n; j ++ )
            tmpDataPoints.push_back(tmpControlPoints[j][i]);
        getFittingControlPoints(tmpDataPoints, controlPoints[i], k, h);
    }

}


void MyBSplineSurface::onInit() {

    int n = 50, k = 3;
    
    // 插值b样条画一个球
    vector<vector<Vector3f>> dataPoints;

    // 下面两个函数，分别生成球上的点（插值用），另一个生成有误差的球上的点（拟合用）
    getSphereDataPoints2D(dataPoints, n+1);
    //getShakySphereDataPoints2D(dataPoints, n+1);

    vector<vector<Vector3f>> controlPoints;

    // 这里决定使用插值还是拟合
    getSphereControlPoints2D(dataPoints, controlPoints, k);
    // int h = 10;
    // getFittingControlPoints2D(dataPoints, controlPoints, k, h);

    // 下面两个循环用来画数值点（红色），和得到的控制顶点（绿色）
    for (int i = 0; i < dataPoints.size(); i++)
    {
        //putPointsToRenderingList(dataPoints[i]);
    }
    for (int i = 0; i < controlPoints.size(); i++)
    {
        //putPointsToRenderingList(controlPoints[i], Vector3f(0,1,0));
    }
    
    int drawNum = 100;
    getBSplineSurface(drawNum, drawNum, controlPoints, k);
    

    // // 画一条随机顶点的插值B-样条
    // vector<Vector3f> dataPoints;
    // // 随机生成n+1个 dataPoints，为了方便，让他们的z值都为0，即在同一平面上
    // srand( time(0) );
    // float dn = 2.f / (n+1);     
    // for( int j = 0; j < n+1; j ++ ) {
    //     float randx = -1 + j * dn + dn * (rand() % 1000 / 1000.f);
    //     randx *= 0.8;
    //     float randy = (rand() % 1000 - 500) / 600.f;
    //     // float randz = (rand() % 1000 - 500) / 500.f;
    //     dataPoints.push_back(Vector3f(randx, randy, 0));
    // }

    // putPointsToRenderingList(dataPoints, Vector3f(0,0,1));

    // vector<Vector3f> controlPoints;
    // //getInterpolationControlPoints(dataPoints, controlPoints, k);
    // getFittingControlPoints(dataPoints, controlPoints, k, 9);
    // putPointsToRenderingList(controlPoints, Vector3f(0,1,0));

    // vector<Vector3f> drawPointsRec;
    // getBSpline(200, drawPointsRec, controlPoints, k);
    
    // putPointsToRenderingList(drawPointsRec);
    

    // // 画一下基函数曲线
    // vector<float> knots;
    // setKnots(knots, n, k);
    // int drawNum = 101;
    // float dt = 1.f / drawNum;
    
    // for( int num = 0; num < n+1; num ++ ) {
    //     vector<Vector3f> points;
    //     for(int i = 0; i < drawNum; i ++ ) {
    //         float t = dt * i;
    //         if(t == 1)
    //             t -= dt/2;
    //         points.push_back(Vector3f(t-0.5, 0.5*countBase(num, k, k, t, knots), 0));
            
    //     }
    //     if( num == 3 )
    //         putPointsToRenderingList(points, Vector3f(0.2+0.2*num, 0, 0));
    // }
    


    /* draw bspline surface by some random points
    int m = 3, n = 4;
    int drawNumForM = 11, drawNumForN = 11;
    int k = 4;

    vector<vector<Vector3f>> controlPoints(m+1);
    getRandomControlPoints(controlPoints, m, n);

    for(int i = 0; i < controlPoints.size(); i ++)
        for(int j = 0; j < controlPoints[i].size(); j ++)
            globalPoints.push_back(controlPoints[i][j]);

    getBSplineSurface(drawNumForM, drawNumForN, controlPoints, k);
    */

}

void MyBSplineSurface::putPointsToRenderingList(vector<Vector3f> &Points, Vector3f color) {
    for(int i = 0; i < Points.size(); i ++){
        globalPoints.push_back(Points[i]);
        globalPointsColor.push_back(color);
    }
}

// Optional: Rewrite onMain function, which will get executed in the loop
void MyBSplineSurface::onMain() {
    
    for(Triangle3D &tri : globalTriangles) {
        drawTriangle(tri);
    }

    for(int i = 0; i < globalPoints.size(); i ++ ) {
        drawPoint(globalPoints[i], 3, globalPointsColor[i]);
    }

    
    // Triangle3D tri{Vector3f(-0.5,-0.5,0),
    //             Vector3f(0.5,-0.5,0),
    //             Vector3f(0.5,0.5,0)};
    // drawTriangle(tri);
    // Vector3f red(1,0,0);
    // drawPoint(tri.a(), 5, red);
    // drawPoint(tri.b(), 5, red);
    // drawPoint(tri.c(), 5, red);
}