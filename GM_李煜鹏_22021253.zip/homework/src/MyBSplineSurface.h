#pragma once
#include "Tiny2DEngine.h"
#include "Triangle.h"
#include <vector>
using namespace std;
using namespace Eigen;

class MyBSplineSurface : public Tiny2DEngine {
public:
    float PI = 3.141592;
    vector<Triangle3D> globalTriangles;
    vector<Vector3f> globalPoints;
    vector<Vector3f> globalPointsColor;
    
    // Constructor
    MyBSplineSurface(HINSTANCE hinst, int w, int h) : Tiny2DEngine(hinst, w, h) {}

    void onInit() override;
    float setKnots(vector<float> &knots, int n, int k);
    void getRandomControlPoints(vector<vector<Vector3f>> &controlPoints, int m, int n );
    
    void getInterpolationControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k);
    void getFittingControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k, int h);
    float countBase(int i, int p, float t, vector<float> &knots);

    void getSphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n);
    void getShakySphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n);
    void getSphereControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k);
    void getFittingControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k, int h);

    Vector3f DeBoorCox(float t, int i, int j, vector<float> knots, vector<Vector3f> controls, int k);

    void getBSpline(int drawNum, vector<Vector3f> &rec, vector<Vector3f> &controlPoints, int k);
    void getBSplineSurface(int drawNumForM, int drawNumForN, vector<vector<Vector3f>> &controlPoints, int k);


    void putPointsToRenderingList(vector<Vector3f> &Points, Vector3f color = Vector3f(1,0,0));
    void onMain() override;
};