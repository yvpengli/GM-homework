# 应用几何造型基础作业

- 姓名：李煜鹏

- 学号：22021253

- 项目介绍：本项目完成了用插值和拟合B-样条曲面绘制球面。在项目中，实现了B-样条绘制，B-样条曲面绘制，插值B-样条曲线曲面绘制，拟合B-样条曲线曲面绘制。

- 生成的可执行文件在 ./bin/Release/ 目录下，分别是Interpolation.exe 和 Fitting.exe，分别实现了插值和拟合模拟球面。

- 完成情况：

  - Interpolation.exe 中，数据点是在球面上的点，点的数量是 50*50（n等于50），B-样条阶数 k = 3。可以看到，实现效果还可以，仅有一条细小的线条空隙。
  - Fitting.ext 中，数据点是在球面上取点，并用rand() 函数做了一下抖动，点的数量同样是50*50，B-样条阶数同样是 k = 3。可以看到，实现效果不太好，除了曲面不太光滑外，还有一部分曲面向内部弯曲，造成一条深沟。
  - 总的来说，插值B-样条曲面实现效果更好，也更容易，实现起来也更加可控。

- 本项目的渲染功能部分来自一个GitHub上面的项目，是基于Windows提供的工具渲染的。提供了绘制三角形和鼠标拖拽的渲染功能。该项目地址是：https://github.com/ahhxzyc/Tiny2DEngine

- 本人在这个项目中专注于实现B-样条相关的数据结构和方法。主要工作集中在src文件夹下MyBSpline.cpp，MyBSplineSurface.cpp以及他们对应的 .h 文件中。其中 MyBSpline.cpp 中的数据结构和方法只能用来绘制二维的 B-样条，是我刚开始用来练手的，所以作业的主要的要求的实现在 MyBSplineSurface.cpp 中，下面对 MyBSplineSurface.cpp 中实现的方法进行简单的介绍。

- ```c++
  // 生成结点向量，放在knots中。
  float setKnots(vector<float> &knots, int n, int k);
  // 生成一些随机的控制顶点，该函数在我刚开始写画B-样条曲线的方法时用到，后面不再使用
  void getRandomControlPoints(vector<vector<Vector3f>> &controlPoints, int m, int n );
  
  // 基于给定的dataPoints，生成插值B-样条的控制顶点。
  void getInterpolationControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k);
  // 基于给定的dataPoints，生成拟合B-样条的控制顶点。
  void getFittingControlPoints(vector<Vector3f> &dataPoints, vector<Vector3f> &controlPoints, int k, int h);
  // 用来计算基函数，使用递归实现。
  float countBase(int i, int p, float t, vector<float> &knots);
  
  // 生成球面上的数据点。
  void getSphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n);
  // 生成球面上的数据点，然后抖动一下，让点随机偏移一下。画拟合曲面的时候使用。
  void getShakySphereDataPoints2D(vector<vector<Vector3f>> &dataPoints, int n);
  // 基于给定的二维dataPoints（球面上的数据点），得到二维的插值B-样条的控制顶点
  void getSphereControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k);
  // 基于给定的二维dataPoints，得到二维的拟合B-样条的控制顶点
  void getFittingControlPoints2D(vector<vector<Vector3f>> &dataPoints, vector<vector<Vector3f>> &controlPoints, int k, int h);
  
  // 实现绘制B-样条时用的DeBoorCox算法
  Vector3f DeBoorCox(float t, int i, int j, vector<float> knots, vector<Vector3f> controls, int k);
  
  // 给定控制顶点controlPoints，画出B-样条曲线，保存在 rec数组中
  void getBSpline(int drawNum, vector<Vector3f> &rec, vector<Vector3f> &controlPoints, int k);
  // 给定二维控制顶点controlPoints，画出B-样条曲面。
  void getBSplineSurface(int drawNumForM, int drawNumForN, vector<vector<Vector3f>> &controlPoints, int k);
  
  // 把得到的点放入绘制列表中，让渲染引擎渲染。
  void putPointsToRenderingList(vector<Vector3f> &Points, Vector3f color = Vector3f(1,0,0));
  ```

  